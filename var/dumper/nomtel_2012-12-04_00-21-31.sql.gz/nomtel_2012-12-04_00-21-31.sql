#SXD20|20009|50528|50310|2012.12.04 00:21:31|nomtel|0|1|1|
#TA user`1`16384
#EOH

#	TC`user`utf8_general_ci	;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `status` enum('ACTIVE','BLOCKED') NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) DEFAULT NULL,
  `failed_logins` int(11) DEFAULT NULL,
  `blocked_until` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TD`user`utf8_general_ci	;
INSERT INTO `user` VALUES 
(1,'ACTIVE','pavimus','$6$guAQkKGd$mt.gBSnK3j43MMYntjgQG3RLUbYi6cMiD.1lZLoAl.rYknGu/ViBYaaA7nqr5iPv.gXr1LusfKjCZqbOpXrJY1',0,\N)	;
