#SXD20|20009|50528|50310|2012.12.22 04:35:27|nomtel|0|11|47|
#TA agent`8`16384|agent_referral_rate`15`16384|bonus_report`0`16384|delivery_report`0`16384|operator`3`16384|payment`0`16384|sim`0`16384|tariff`4`16384|ticket`4`16384|ticket_message`4`16384|user`9`16384
#EOH

#	TC`agent`utf8_general_ci	;
CREATE TABLE `agent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `middle_name` varchar(100) NOT NULL,
  `phone_1` varchar(50) NOT NULL,
  `phone_2` varchar(50) DEFAULT NULL,
  `phone_3` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `skype` varchar(100) DEFAULT NULL,
  `icq` varchar(20) DEFAULT NULL,
  `passport_series` varchar(10) NOT NULL,
  `passport_number` varchar(20) NOT NULL,
  `passport_issue_date` date NOT NULL,
  `passport_issuer` varchar(200) NOT NULL,
  `birthday_date` date NOT NULL,
  `birthday_place` varchar(200) NOT NULL,
  `registration_address` varchar(200) NOT NULL,
  `balance` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `agent_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `agent_ibfk_2` FOREIGN KEY (`parent_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8	;
#	TD`agent`utf8_general_ci	;
INSERT INTO `agent` VALUES 
(2,\N,2,'pavel','hushcha','ivanovich','433297',\N,\N,\N,\N,\N,'ab','12345','2012-12-04','kem','2012-12-18','place','address',-99.11272),
(3,\N,3,'Павел','Гуща','Иванович','433297',\N,\N,\N,\N,\N,'1','2','2012-12-04','1','2012-12-07','1','1',0),
(4,\N,4,'Алексей','Гудков','Андреевич','89292000003',\N,\N,\N,\N,\N,'9205','339270','2007-12-07','ГУВД г. Казань','1989-12-01','Перьм','г.Казань ул. Амирхана 105-45',0),
(5,2,5,'subagent','subagent','subagent','4',\N,\N,\N,\N,\N,'1','1','2012-12-18','1','2012-12-18','fgfgf','1',-99.77818),
(6,5,6,'subsubagent','subsubagent','subsubagent','subsubagent',\N,\N,\N,\N,\N,'1','1111','2012-12-03','1','2012-12-18','1','1',0),
(8,\N,8,'ыва','ыыва','ыа','ыва',\N,\N,\N,\N,\N,'ыва','ыва','2012-12-03','ыва','2012-12-19','вап','вап',0),
(9,2,9,'subagent2','subagent2','subagent2','subagent2',\N,\N,\N,\N,\N,'subagent2','subagent2','2012-12-18','subagent2','2012-12-27','subagent2','subagent2',0),
(10,\N,10,'subagent3','subagent3','subagent3','subagent3',\N,\N,\N,\N,\N,'subagent3','subagent3','2012-12-04','subagent3','2012-12-26','subagent3','subagent3',0)	;
#	TC`agent_referral_rate`utf8_general_ci	;
CREATE TABLE `agent_referral_rate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_agent_id` int(11) DEFAULT NULL,
  `agent_id` int(11) NOT NULL,
  `operator_id` int(11) NOT NULL,
  `rate` double NOT NULL COMMENT 'ставка бонусных отчислений в процентах',
  PRIMARY KEY (`id`),
  KEY `agent_id` (`agent_id`),
  KEY `operator_id` (`operator_id`),
  KEY `referral_agent_id` (`parent_agent_id`),
  CONSTRAINT `agent_referral_rate_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agent` (`id`),
  CONSTRAINT `agent_referral_rate_ibfk_3` FOREIGN KEY (`operator_id`) REFERENCES `operator` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8	;
#	TD`agent_referral_rate`utf8_general_ci	;
INSERT INTO `agent_referral_rate` VALUES 
(1,\N,8,5,1),
(2,\N,8,1,2),
(3,\N,8,2,3),
(4,2,9,5,5),
(5,2,9,1,6),
(6,2,9,2,7),
(7,\N,10,5,20),
(8,\N,10,1,21),
(9,\N,10,2,22),
(13,\N,2,5,9),
(14,\N,2,1,10),
(15,\N,2,2,11),
(16,2,5,5,19),
(17,2,5,1,20),
(18,2,5,2,21)	;
#	TC`bonus_report`utf8_general_ci	;
CREATE TABLE `bonus_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `operator_id` int(11) NOT NULL,
  `comment` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `operator_id` (`operator_id`),
  CONSTRAINT `bonus_report_ibfk_1` FOREIGN KEY (`operator_id`) REFERENCES `operator` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8	;
#	TC`delivery_report`utf8_general_ci	;
CREATE TABLE `delivery_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_id` int(11) NOT NULL,
  `bonus_report_id` int(11) DEFAULT NULL,
  `dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sim_price` double NOT NULL,
  `sum` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `agent_id` (`agent_id`),
  KEY `bonus_report_id` (`bonus_report_id`),
  CONSTRAINT `delivery_report_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agent` (`id`),
  CONSTRAINT `delivery_report_ibfk_2` FOREIGN KEY (`agent_id`) REFERENCES `agent` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8	;
#	TC`operator`utf8_general_ci	;
CREATE TABLE `operator` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8	;
#	TD`operator`utf8_general_ci	;
INSERT INTO `operator` VALUES 
(1,'Билайн'),
(2,'Мегафон'),
(5,'test2')	;
#	TC`payment`utf8_general_ci	;
CREATE TABLE `payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_id` int(11) NOT NULL,
  `type` enum('NORMAL','BONUS') NOT NULL,
  `bonus_report_id` int(11) DEFAULT NULL,
  `comment` varchar(200) DEFAULT NULL,
  `dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sum` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `agent_id` (`agent_id`),
  KEY `bonus_report_id` (`bonus_report_id`),
  CONSTRAINT `payment_ibfk_2` FOREIGN KEY (`bonus_report_id`) REFERENCES `bonus_report` (`id`),
  CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agent` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`sim`utf8_general_ci	;
CREATE TABLE `sim` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `state` enum('NOT_RECEIVED','IN_BASE','DELIVERED_TO_AGENT') NOT NULL,
  `personal_account` varchar(50) NOT NULL,
  `number` varchar(50) DEFAULT NULL,
  `number_price` double NOT NULL,
  `icc` varchar(50) DEFAULT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  `parent_agent_id` int(11) DEFAULT NULL,
  `parent_delivery_report_id` int(11) DEFAULT NULL,
  `agent_id` int(11) DEFAULT NULL,
  `delivery_report_id` int(11) DEFAULT NULL,
  `operator_id` int(11) DEFAULT NULL,
  `tariff_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tarif_id` (`tariff_id`),
  KEY `operator_id` (`operator_id`),
  KEY `delivery_report_id` (`delivery_report_id`),
  KEY `parent_agent_id` (`parent_agent_id`),
  KEY `agent_id_state` (`agent_id`,`state`),
  KEY `icc` (`icc`),
  KEY `personal_account` (`personal_account`),
  KEY `parent_delivery_report_id` (`parent_delivery_report_id`),
  KEY `parent_id` (`parent_id`),
  KEY `number` (`number`),
  CONSTRAINT `sim_ibfk_13` FOREIGN KEY (`parent_id`) REFERENCES `sim` (`id`),
  CONSTRAINT `sim_ibfk_10` FOREIGN KEY (`delivery_report_id`) REFERENCES `delivery_report` (`id`),
  CONSTRAINT `sim_ibfk_11` FOREIGN KEY (`parent_agent_id`) REFERENCES `agent` (`id`),
  CONSTRAINT `sim_ibfk_12` FOREIGN KEY (`parent_delivery_report_id`) REFERENCES `delivery_report` (`id`),
  CONSTRAINT `sim_ibfk_5` FOREIGN KEY (`tariff_id`) REFERENCES `tariff` (`id`),
  CONSTRAINT `sim_ibfk_8` FOREIGN KEY (`operator_id`) REFERENCES `operator` (`id`),
  CONSTRAINT `sim_ibfk_9` FOREIGN KEY (`agent_id`) REFERENCES `agent` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`tariff`utf8_general_ci	;
CREATE TABLE `tariff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `operator_id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `price_agent_sim` double NOT NULL,
  `price_license_fee` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `operator_id` (`operator_id`),
  CONSTRAINT `tariff_ibfk_1` FOREIGN KEY (`operator_id`) REFERENCES `operator` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8	;
#	TD`tariff`utf8_general_ci	;
INSERT INTO `tariff` VALUES 
(1,1,'Отличный',0,0),
(2,1,'Приличный',0,0),
(3,2,'Про 100',0,0),
(4,2,'Про 200',0,0)	;
#	TC`ticket`utf8_general_ci	;
CREATE TABLE `ticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_id` int(11) NOT NULL,
  `title` varchar(256) NOT NULL,
  `date` datetime NOT NULL,
  `whom` int(11) DEFAULT NULL,
  `status` enum('NEW','VIEWED') DEFAULT 'NEW',
  PRIMARY KEY (`id`),
  KEY `agent_id` (`agent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8	;
#	TD`ticket`utf8_general_ci	;
INSERT INTO `ticket` VALUES 
(7,2,'Привет','2012-12-21 00:00:00',\N,'NEW'),
(8,2,'Ппривет ещё раз','2012-12-21 00:00:00',\N,'NEW'),
(9,2,'Тест','2012-12-21 01:38:26',\N,'NEW'),
(10,2,'сообщение рефералу','2012-12-21 01:45:47',5,'NEW')	;
#	TC`ticket_message`utf8_general_ci	;
CREATE TABLE `ticket_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `agent_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_id` (`ticket_id`),
  KEY `ticket_id_2` (`ticket_id`),
  CONSTRAINT `ticket_message_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `ticket` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8	;
#	TD`ticket_message`utf8_general_ci	;
INSERT INTO `ticket_message` VALUES 
(2,7,2,'Сообщение','2012-12-21'),
(3,8,2,'Ещё одно  новое сообщение !','2012-12-21'),
(4,9,2,'Тест','2012-12-21'),
(5,10,2,'Привет !','2012-12-21')	;
#	TC`user`utf8_general_ci	;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('ACTIVE','BLOCKED') NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) DEFAULT NULL,
  `failed_logins` int(11) DEFAULT NULL,
  `blocked_until` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8	;
#	TD`user`utf8_general_ci	;
INSERT INTO `user` VALUES 
(1,'ACTIVE','pavimus','$6$guAQkKGd$mt.gBSnK3j43MMYntjgQG3RLUbYi6cMiD.1lZLoAl.rYknGu/ViBYaaA7nqr5iPv.gXr1LusfKjCZqbOpXrJY1',0,\N),
(2,'ACTIVE','pavel','$2a$13$6O8aDjh00Y54jsUqDdEEhOtouU3NKcQ5ndim7ee6Y5qlsJrYyf3tS',0,\N),
(3,'ACTIVE','pavel2','$2a$13$cgumCZ.ZMARkZf4Q/4K1KeIZDkjCCU3aYhB.k.9xutHU/faD5NJ3K',\N,\N),
(4,'ACTIVE','alegud','$2a$13$4YPwsAxyri0MZ/VGY6MuPuBBSoYFbiUk.ZNw11CZoQeooytLRVZYW',0,\N),
(5,'ACTIVE','subagent','$2a$13$HfDParK4ECsjdOn41u4oI.Z1gylOsQYoJHA56.V/1JoA5jQAzakD2',\N,\N),
(6,'ACTIVE','subsubagent','$2a$13$qWPBMxGbE6US.UuNFC1lruknbKSHE5tCDRNOAnzaErnkAwsd2KUbK',\N,\N),
(8,'ACTIVE','sda','$2a$13$b7lAiAispAe05xP8PFcs4O.tG.LRl0up3K.4.pFDIuIdGY89rrcnC',\N,\N),
(9,'ACTIVE','subagent2','$2a$13$aFaONMmR45hsKuIX3r8CF..pPIaz8NcDlIlbBglxXb4F.T4831u0C',\N,\N),
(10,'ACTIVE','subagent3','$2a$13$VUvIgVsNklQiX/vc3tOE7.A9cB2AKbiHuQixv8Ndr6E9iqj2LRzAm',\N,\N)	;
