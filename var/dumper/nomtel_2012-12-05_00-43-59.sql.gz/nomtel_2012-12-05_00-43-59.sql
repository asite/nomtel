#SXD20|20009|50528|50310|2012.12.05 00:43:59|nomtel|0|7|1|
#TA agent`0`16384|delivery_report`0`16384|operator`0`16384|payment`0`16384|sim`0`16384|tariff`0`16384|user`1`16384
#EOH

#	TC`agent`utf8_general_ci	;
CREATE TABLE `agent` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `middle_name` varchar(100) NOT NULL,
  `phone1` varchar(50) NOT NULL,
  `phone2` varchar(50) DEFAULT NULL,
  `phone3` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `skype` varchar(100) DEFAULT NULL,
  `icq` varchar(20) DEFAULT NULL,
  `passport_series` varchar(10) NOT NULL,
  `passport_number` varchar(20) NOT NULL,
  `passport_issue_date` date NOT NULL,
  `passport_issuer` varchar(200) NOT NULL,
  `birthday_date` date NOT NULL,
  `birthday_place` varchar(200) NOT NULL,
  `registration_place` varchar(200) NOT NULL,
  `balance` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `agent_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`delivery_report`utf8_general_ci	;
CREATE TABLE `delivery_report` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `agent_id` bigint(20) NOT NULL,
  `dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `summ` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `agent_id` (`agent_id`),
  CONSTRAINT `delivery_report_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agent` (`id`),
  CONSTRAINT `delivery_report_ibfk_2` FOREIGN KEY (`agent_id`) REFERENCES `agent` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`operator`utf8_general_ci	;
CREATE TABLE `operator` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`payment`utf8_general_ci	;
CREATE TABLE `payment` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `agent_id` bigint(20) NOT NULL,
  `summ` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `agent_id` (`agent_id`),
  CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agent` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`sim`utf8_general_ci	;
CREATE TABLE `sim` (
  `id` bigint(20) NOT NULL,
  `state` enum('''NOT_RECEIVED'',''','''IN_BASE'',''DELIVERED_TO_AGENT''') NOT NULL,
  `agent_id` bigint(20) DEFAULT NULL,
  `delivery_report_id` bigint(20) DEFAULT NULL,
  `personal_account` varchar(50) NOT NULL,
  `number` varchar(50) DEFAULT NULL,
  `number_price` double NOT NULL,
  `icc` varchar(50) NOT NULL,
  `operator_id` bigint(20) DEFAULT NULL,
  `tariff_id` bigint(20) DEFAULT NULL,
  KEY `agent_id` (`agent_id`),
  KEY `tarif_id` (`tariff_id`),
  KEY `delivery_report_id` (`delivery_report_id`),
  CONSTRAINT `sim_ibfk_6` FOREIGN KEY (`tariff_id`) REFERENCES `tariff` (`id`),
  CONSTRAINT `sim_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agent` (`id`),
  CONSTRAINT `sim_ibfk_4` FOREIGN KEY (`delivery_report_id`) REFERENCES `delivery_report` (`id`),
  CONSTRAINT `sim_ibfk_5` FOREIGN KEY (`tariff_id`) REFERENCES `tariff` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`tariff`utf8_general_ci	;
CREATE TABLE `tariff` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `operator_id` bigint(20) NOT NULL,
  `price_agent_sim` double NOT NULL,
  `price_license_fee` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `operator_id` (`operator_id`),
  CONSTRAINT `tariff_ibfk_1` FOREIGN KEY (`operator_id`) REFERENCES `operator` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`user`utf8_general_ci	;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `status` enum('ACTIVE','BLOCKED') NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) DEFAULT NULL,
  `failed_logins` int(11) DEFAULT NULL,
  `blocked_until` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TD`user`utf8_general_ci	;
INSERT INTO `user` VALUES 
(1,'ACTIVE','pavimus','$6$guAQkKGd$mt.gBSnK3j43MMYntjgQG3RLUbYi6cMiD.1lZLoAl.rYknGu/ViBYaaA7nqr5iPv.gXr1LusfKjCZqbOpXrJY1',0,\N)	;
