#SXD20|20009|50528|50310|2012.12.24 15:31:02|nomtel|0|12|92|
#TA agent`9`16384|agent_referral_rate`18`16384|bonus_report`3`16384|bonus_report_agent`9`16384|delivery_report`6`16384|operator`3`16384|payment`9`16384|sim`3`16384|tariff`4`16384|ticket`8`16384|ticket_message`11`16384|user`9`16384
#EOH

#	TC`agent`utf8_general_ci	;
CREATE TABLE `agent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `middle_name` varchar(100) NOT NULL,
  `phone_1` varchar(50) NOT NULL,
  `phone_2` varchar(50) DEFAULT NULL,
  `phone_3` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `skype` varchar(100) DEFAULT NULL,
  `icq` varchar(20) DEFAULT NULL,
  `passport_series` varchar(10) NOT NULL,
  `passport_number` varchar(20) NOT NULL,
  `passport_issue_date` date NOT NULL,
  `passport_issuer` varchar(200) NOT NULL,
  `birthday_date` date NOT NULL,
  `birthday_place` varchar(200) NOT NULL,
  `registration_address` varchar(200) NOT NULL,
  `balance` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `agent_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `agent_ibfk_2` FOREIGN KEY (`parent_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8	;
#	TD`agent`utf8_general_ci	;
INSERT INTO `agent` VALUES 
(1,\N,1,'admin','admin','admin','admin',\N,\N,\N,\N,\N,'admin','admin','2012-12-22','admin','2012-12-22','admin','admin',-102.5281),
(2,1,2,'pavel','hushcha','ivanovich','433297',\N,\N,\N,\N,\N,'ab','12345','2012-12-04','kem','2012-12-18','place','address',124.69728),
(3,1,3,'Павел','Гуща','Иванович','433297',\N,\N,\N,\N,\N,'1','2','2012-12-04','1','2012-12-07','1','1',0),
(4,1,4,'Алексей','Гудков','Андреевич','89292000003',\N,\N,\N,\N,\N,'9205','339270','2007-12-07','ГУВД г. Казань','1989-12-01','Перьм','г.Казань ул. Амирхана 105-45',0),
(5,2,5,'subagent','subagent','subagent','4',\N,\N,\N,\N,\N,'1','1','2012-12-18','1','2012-12-18','fgfgf','1',-1493.76818),
(6,5,6,'subsubagent','subsubagent','subsubagent','subsubagent',\N,\N,\N,\N,\N,'1','1111','2012-12-03','1','2012-12-18','1','1',0),
(8,\N,8,'ыва','ыыва','ыа','ыва',\N,\N,\N,\N,\N,'ыва','ыва','2012-12-03','ыва','2012-12-19','вап','вап',0),
(9,2,9,'subagent2','subagent2','subagent2','subagent2',\N,\N,\N,\N,\N,'subagent2','subagent2','2012-12-18','subagent2','2012-12-27','subagent2','subagent2',0),
(10,\N,10,'subagent3','subagent3','subagent3','subagent3',\N,\N,\N,\N,\N,'subagent3','subagent3','2012-12-04','subagent3','2012-12-26','subagent3','subagent3',0)	;
#	TC`agent_referral_rate`utf8_general_ci	;
CREATE TABLE `agent_referral_rate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_agent_id` int(11) DEFAULT NULL,
  `agent_id` int(11) NOT NULL,
  `operator_id` int(11) NOT NULL,
  `rate` double NOT NULL COMMENT 'ставка бонусных отчислений в процентах',
  PRIMARY KEY (`id`),
  KEY `agent_id` (`agent_id`),
  KEY `operator_id` (`operator_id`),
  KEY `referral_agent_id` (`parent_agent_id`),
  CONSTRAINT `agent_referral_rate_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agent` (`id`),
  CONSTRAINT `agent_referral_rate_ibfk_3` FOREIGN KEY (`operator_id`) REFERENCES `operator` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8	;
#	TD`agent_referral_rate`utf8_general_ci	;
INSERT INTO `agent_referral_rate` VALUES 
(1,\N,8,5,1),
(2,\N,8,1,2),
(3,\N,8,2,3),
(4,2,9,5,5),
(5,2,9,1,6),
(6,2,9,2,7),
(7,\N,10,5,20),
(8,\N,10,1,21),
(9,\N,10,2,22),
(13,\N,2,5,9),
(14,\N,2,1,8),
(15,\N,2,2,11),
(16,2,5,5,19),
(17,2,5,1,5),
(18,2,5,2,5),
(19,\N,1,5,10),
(20,\N,1,1,11),
(21,\N,1,2,12)	;
#	TC`bonus_report`utf8_general_ci	;
CREATE TABLE `bonus_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `operator_id` int(11) NOT NULL,
  `comment` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `operator_id` (`operator_id`),
  CONSTRAINT `bonus_report_ibfk_1` FOREIGN KEY (`operator_id`) REFERENCES `operator` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8	;
#	TD`bonus_report`utf8_general_ci	;
INSERT INTO `bonus_report` VALUES 
(12,'2012-12-22 14:32:46',1,'test'),
(13,'2012-12-24 12:23:34',1,'test'),
(14,'2012-12-24 14:29:26',2,'test3')	;
#	TC`bonus_report_agent`utf8_general_ci	;
CREATE TABLE `bonus_report_agent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bonus_report_id` int(11) NOT NULL,
  `agent_id` int(11) NOT NULL,
  `sim_count` int(11) NOT NULL,
  `sum` double NOT NULL,
  `sum_referrals` double NOT NULL,
  `payment_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bonus_report_id` (`bonus_report_id`),
  KEY `agent_id` (`agent_id`),
  KEY `payment_id` (`payment_id`),
  CONSTRAINT `bonus_report_agent_ibfk_1` FOREIGN KEY (`bonus_report_id`) REFERENCES `bonus_report` (`id`),
  CONSTRAINT `bonus_report_agent_ibfk_2` FOREIGN KEY (`agent_id`) REFERENCES `agent` (`id`),
  CONSTRAINT `bonus_report_agent_ibfk_5` FOREIGN KEY (`payment_id`) REFERENCES `payment` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8	;
#	TD`bonus_report_agent`utf8_general_ci	;
INSERT INTO `bonus_report_agent` VALUES 
(1,12,1,1,11.091,1.1091,4),
(2,12,2,1,1.1091,0.22182,5),
(3,12,5,1,0.22182,0,6),
(4,13,1,1,8.13,5.91,7),
(5,13,2,1,5.91,3.69,8),
(6,13,5,1,3.69,0,9),
(7,14,1,1,243.18,222.91,10),
(8,14,2,1,222.91,101.32,11),
(9,14,5,1,101.32,0,12)	;
#	TC`delivery_report`utf8_general_ci	;
CREATE TABLE `delivery_report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_id` int(11) NOT NULL,
  `bonus_report_id` int(11) DEFAULT NULL,
  `dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sum` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `agent_id` (`agent_id`),
  KEY `bonus_report_id` (`bonus_report_id`),
  CONSTRAINT `delivery_report_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agent` (`id`),
  CONSTRAINT `delivery_report_ibfk_2` FOREIGN KEY (`agent_id`) REFERENCES `agent` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8	;
#	TD`delivery_report`utf8_general_ci	;
INSERT INTO `delivery_report` VALUES 
(13,2,\N,'2012-12-22 13:37:30',100),
(14,2,\N,'2012-12-22 13:38:11',100),
(15,5,\N,'2012-12-22 13:38:32',100),
(16,1,\N,'2012-12-24 12:22:39',135),
(17,5,\N,'2012-12-24 12:30:19',500),
(18,5,\N,'2012-12-24 12:42:44',999)	;
#	TC`operator`utf8_general_ci	;
CREATE TABLE `operator` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8	;
#	TD`operator`utf8_general_ci	;
INSERT INTO `operator` VALUES 
(1,'Билайн'),
(2,'Мегафон'),
(5,'test2')	;
#	TC`payment`utf8_general_ci	;
CREATE TABLE `payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_id` int(11) NOT NULL,
  `type` enum('NORMAL','BONUS') NOT NULL,
  `comment` varchar(200) DEFAULT NULL,
  `dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sum` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `agent_id` (`agent_id`),
  CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agent` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8	;
#	TD`payment`utf8_general_ci	;
INSERT INTO `payment` VALUES 
(4,1,'BONUS','Бонусы \'test\'','2012-12-22 14:32:46',9.9819),
(5,2,'BONUS','Бонусы \'test\'','2012-12-22 14:32:46',0.88728),
(6,5,'BONUS','Бонусы \'test\'','2012-12-22 14:32:46',0.22182),
(7,1,'BONUS','Бонусы \'test\'','2012-12-24 12:23:35',2.220000000000001),
(8,2,'BONUS','Бонусы \'test\'','2012-12-24 12:23:35',2.22),
(9,5,'BONUS','Бонусы \'test\'','2012-12-24 12:23:35',3.69),
(10,1,'BONUS','Бонусы \'test3\'','2012-12-24 14:29:26',20.27000000000001),
(11,2,'BONUS','Бонусы \'test3\'','2012-12-24 14:29:26',121.59),
(12,5,'BONUS','Бонусы \'test3\'','2012-12-24 14:29:26',101.32)	;
#	TC`sim`utf8_general_ci	;
CREATE TABLE `sim` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `personal_account` varchar(50) NOT NULL,
  `number` varchar(50) DEFAULT NULL,
  `number_price` double NOT NULL DEFAULT '0',
  `sim_price` double NOT NULL DEFAULT '0',
  `icc` varchar(50) DEFAULT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  `parent_agent_id` int(11) DEFAULT NULL COMMENT 'NULL, если  симка еще не добавлена, =1 если симка в базе',
  `parent_delivery_report_id` int(11) DEFAULT NULL COMMENT 'по какой delivery_report симка попала агенту parent_agent_id',
  `agent_id` int(11) DEFAULT NULL COMMENT 'какому агенту передал симку агент parent_agent_id',
  `delivery_report_id` int(11) DEFAULT NULL COMMENT 'по какой delivery_report он ее передал',
  `operator_id` int(11) DEFAULT NULL,
  `tariff_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tarif_id` (`tariff_id`),
  KEY `operator_id` (`operator_id`),
  KEY `delivery_report_id` (`delivery_report_id`),
  KEY `parent_agent_id` (`parent_agent_id`),
  KEY `agent_id_state` (`agent_id`),
  KEY `icc` (`icc`),
  KEY `personal_account` (`personal_account`),
  KEY `parent_delivery_report_id` (`parent_delivery_report_id`),
  KEY `parent_id` (`parent_id`),
  KEY `number` (`number`),
  CONSTRAINT `sim_ibfk_10` FOREIGN KEY (`delivery_report_id`) REFERENCES `delivery_report` (`id`),
  CONSTRAINT `sim_ibfk_11` FOREIGN KEY (`parent_agent_id`) REFERENCES `agent` (`id`),
  CONSTRAINT `sim_ibfk_12` FOREIGN KEY (`parent_delivery_report_id`) REFERENCES `delivery_report` (`id`),
  CONSTRAINT `sim_ibfk_13` FOREIGN KEY (`parent_id`) REFERENCES `sim` (`id`),
  CONSTRAINT `sim_ibfk_5` FOREIGN KEY (`tariff_id`) REFERENCES `tariff` (`id`),
  CONSTRAINT `sim_ibfk_8` FOREIGN KEY (`operator_id`) REFERENCES `operator` (`id`),
  CONSTRAINT `sim_ibfk_9` FOREIGN KEY (`agent_id`) REFERENCES `agent` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`sim`utf8_general_ci	;
INSERT INTO `sim` VALUES 
(1,'21449287','21449287',0,100,'21449287',\N,1,\N,2,14,2,\N),
(2,'21449287','21449287',0,100,'21449287',1,2,14,5,15,2,\N),
(3,'21449287','21449287',0,100,'21449287',2,5,15,\N,\N,2,\N)	;
#	TC`tariff`utf8_general_ci	;
CREATE TABLE `tariff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `operator_id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `price_agent_sim` double NOT NULL,
  `price_license_fee` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `operator_id` (`operator_id`),
  CONSTRAINT `tariff_ibfk_1` FOREIGN KEY (`operator_id`) REFERENCES `operator` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8	;
#	TD`tariff`utf8_general_ci	;
INSERT INTO `tariff` VALUES 
(1,1,'Отличный',0,0),
(2,1,'Приличный',0,0),
(3,2,'Про 100',0,0),
(4,2,'Про 200',0,0)	;
#	TC`ticket`utf8_general_ci	;
CREATE TABLE `ticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_id` int(11) NOT NULL,
  `title` varchar(256) DEFAULT NULL,
  `dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `whom` int(11) NOT NULL,
  `status` enum('NEW','VIEWED','CLOSED') DEFAULT 'NEW',
  `prise` double DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `agent_id` (`agent_id`),
  KEY `whom` (`whom`),
  CONSTRAINT `ticket_ibfk_2` FOREIGN KEY (`whom`) REFERENCES `agent` (`id`),
  CONSTRAINT `ticket_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agent` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8	;
#	TD`ticket`utf8_general_ci	;
INSERT INTO `ticket` VALUES 
(23,1,'Тестовое 1','2012-12-24 12:24:03',2,'CLOSED',0),
(24,1,'Тестовое 2','2012-12-24 12:24:13',3,'NEW',0),
(25,1,'Тестовое 3','2012-12-24 12:24:34',5,'NEW',0),
(26,2,'Тестовое 4','2012-12-24 12:25:39',1,'NEW',0),
(27,2,'Тестовое 5','2012-12-24 12:25:49',3,'NEW',0),
(28,5,'от subagent !','2012-12-24 12:28:09',2,'CLOSED',999),
(29,5,'от subagent 2','2012-12-24 12:28:16',3,'NEW',0),
(30,5,'от subagent 3','2012-12-24 12:28:22',1,'CLOSED',0)	;
#	TC`ticket_message`utf8_general_ci	;
CREATE TABLE `ticket_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `agent_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ticket_id` (`ticket_id`),
  KEY `ticket_id_2` (`ticket_id`),
  CONSTRAINT `ticket_message_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `ticket` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8	;
#	TD`ticket_message`utf8_general_ci	;
INSERT INTO `ticket_message` VALUES 
(32,23,1,'Тестовое 1','2012-12-24 12:24:03'),
(33,24,1,'Тестовое 2','2012-12-24 12:24:13'),
(34,25,1,'Тестовое 3','2012-12-24 12:24:34'),
(35,26,2,'Тестовое 4','2012-12-24 12:25:39'),
(36,27,2,'Тестовое 5','2012-12-24 12:25:49'),
(37,23,2,'ответ 1','2012-12-24 12:25:59'),
(38,28,5,'от subagent !','2012-12-24 12:28:09'),
(39,29,5,'от subagent 2','2012-12-24 12:28:16'),
(40,30,5,'от subagent 3','2012-12-24 12:28:22'),
(41,30,1,'Ок','2012-12-24 12:28:52'),
(42,28,2,'asd','2012-12-24 12:37:56')	;
#	TC`user`utf8_general_ci	;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('ACTIVE','BLOCKED') NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) DEFAULT NULL,
  `failed_logins` int(11) DEFAULT NULL,
  `blocked_until` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8	;
#	TD`user`utf8_general_ci	;
INSERT INTO `user` VALUES 
(1,'ACTIVE','pavimus','$6$guAQkKGd$mt.gBSnK3j43MMYntjgQG3RLUbYi6cMiD.1lZLoAl.rYknGu/ViBYaaA7nqr5iPv.gXr1LusfKjCZqbOpXrJY1',0,\N),
(2,'ACTIVE','pavel','$2a$13$6O8aDjh00Y54jsUqDdEEhOtouU3NKcQ5ndim7ee6Y5qlsJrYyf3tS',0,\N),
(3,'ACTIVE','pavel2','$2a$13$cgumCZ.ZMARkZf4Q/4K1KeIZDkjCCU3aYhB.k.9xutHU/faD5NJ3K',0,\N),
(4,'ACTIVE','alegud','$2a$13$4YPwsAxyri0MZ/VGY6MuPuBBSoYFbiUk.ZNw11CZoQeooytLRVZYW',0,\N),
(5,'ACTIVE','subagent','$2a$13$HfDParK4ECsjdOn41u4oI.Z1gylOsQYoJHA56.V/1JoA5jQAzakD2',0,\N),
(6,'ACTIVE','subsubagent','$2a$13$qWPBMxGbE6US.UuNFC1lruknbKSHE5tCDRNOAnzaErnkAwsd2KUbK',\N,\N),
(8,'ACTIVE','sda','$2a$13$b7lAiAispAe05xP8PFcs4O.tG.LRl0up3K.4.pFDIuIdGY89rrcnC',\N,\N),
(9,'ACTIVE','subagent2','$2a$13$aFaONMmR45hsKuIX3r8CF..pPIaz8NcDlIlbBglxXb4F.T4831u0C',\N,\N),
(10,'ACTIVE','subagent3','$2a$13$VUvIgVsNklQiX/vc3tOE7.A9cB2AKbiHuQixv8Ndr6E9iqj2LRzAm',\N,\N)	;
